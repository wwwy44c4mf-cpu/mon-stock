# Mon Stock — application mobile de gestion de stock

Prototype MVP en français : application web mobile installable (PWA), React/Vite, Supabase Auth + PostgreSQL, scan de codes-barres avec ZXing et fonction d'e-mail via Resend.

> **État actuel : application complète côté code, à déployer et valider sur ton projet Supabase.** Les fonctionnalités ci-dessous sont écrites, mais le build et les tests intégrés (RLS, e-mails, multi-utilisateurs) restent à faire sur ton environnement. N'importe pas de stock réel avant d'avoir suivi la checklist « Mise en route » et fait les tests de la section 3.

## Mise en route (projet Supabase déjà créé) — dans cet ordre

1. **Désactive les inscriptions libres** : Supabase → Authentication → Sign In / Providers → désactive « Allow new users to sign up ». *Indispensable* : sinon n'importe qui possédant l'URL et la clé publique pourrait créer un compte et lire ton stock. Les invitations envoyées depuis l'application continuent de fonctionner.
2. SQL Editor : exécute **dans l'ordre** `202610130001_initial_schema.sql`, puis `202610140001_corrections_et_garde-fous.sql`.
3. Authentication → Users → *Add user* (ton e-mail + mot de passe), puis promeus ce compte admin avec la requête de la section 1, étape 9.
4. Authentication → URL Configuration : **Site URL** = l'adresse de l'application (en local `http://localhost:5173`, puis l'URL de production) et ajoute-la dans *Redirect URLs*. Sans cela, les liens d'invitation et de réinitialisation ne reviennent pas sur l'application.
5. `.env` avec l'URL et la clé publique, `npm install`, `npm run dev`, connexion.
6. Catalogue : onglet **Catalogue** → importer `catalogue-exemple.csv` (ou ton fichier) ; l'import est refusé en bloc si une ligne est invalide ou déjà existante.
7. E-mails : section 2, puis `supabase/schedule-alerts.sql` pour l'envoi automatique toutes les 5 minutes (secret `CRON_SECRET`).

## Fonctionnalités présentes dans le code

- Connexion par e-mail et mot de passe Supabase.
- Tableau de bord et catalogue de produits.
- Recherche par désignation, référence, emplacement ou code-barres.
- Scan via caméra (requiert HTTPS en hébergement, ou localhost en développement).
- Sorties avec quantité par défaut 1 et quantité modifiable.
- Entrées accessibles aux utilisateurs autorisés.
- Historique des mouvements.
- Ajout, modification et archivage de produits pour les comptes disposant du droit correspondant.
- Corrections de stock par comptage (stock constaté + motif obligatoire), avec écart signé dans l'historique.
- Import / export CSV du catalogue (séparateur , ou ;, détection des codes-barres abîmés par Excel).
- Invitation d'un utilisateur : écran de choix du mot de passe à la première connexion, « Mot de passe oublié ? » sur la connexion.
- Le stock ne peut être modifié que via la fonction `record_stock_movement` (déclencheur de garde).
- Réglages des destinataires e-mail pour l'administrateur.
- Schéma SQL avec RLS, RPC transactionnelle, historique, journal d'audit et file d'alertes.
- Fonction Edge pour envoyer les alertes et un e-mail de test.

## Stack

- Node.js 20 ou version LTS compatible
- React + Vite
- Supabase Auth / PostgreSQL / Edge Functions
- `@zxing/browser` pour les codes-barres
- Resend pour l'e-mail (autre fournisseur possible en adaptant la fonction)

## 1. Installer le projet sur son ordinateur

1. Installer Node.js LTS depuis https://nodejs.org/.
2. Décompresser le dossier du projet.
3. Ouvrir un terminal dans le dossier `gestion-stock-app`.
4. Installer les dépendances :

   ```bash
   npm install
   ```

5. Créer un projet Supabase sur https://supabase.com/.
6. Dans **Project Settings → API**, récupérer l'URL du projet et la clé publique/anon (jamais la clé secrète/service_role).
7. Copier `.env.example` vers `.env` et renseigner :

   ```dotenv
   VITE_SUPABASE_URL=https://VOTRE-PROJET.supabase.co
   VITE_SUPABASE_ANON_KEY=VOTRE_CLE_PUBLIQUE
   ```

8. Dans le SQL Editor Supabase, appliquer le contenu de `supabase/migrations/202610130001_initial_schema.sql` sur un projet vierge.
9. Créer le premier utilisateur depuis **Authentication → Users**. Copier son UUID puis, dans le SQL Editor, exécuter la requête ci-dessous en remplaçant l'UUID :

   ```sql
   update public.profiles
   set role = 'admin',
       permissions = '{"manage_products":true,"manage_stock":true,"manage_users":true,"manage_alerts":true}'::jsonb,
       display_name = 'Administrateur'
   where id = 'UUID-DU-COMPTE';
   ```

   Fais cette opération uniquement pour ton compte administrateur. Ne partage pas l'accès SQL Editor aux utilisateurs standards.

10. Démarrer le serveur de développement :

    ```bash
    npm run dev
    ```

11. Ouvrir l'adresse locale affichée par Vite. Le scan caméra peut être limité aux contextes sécurisés ; en local, `localhost` est généralement considéré comme sécurisé.

## 2. Configurer les alertes e-mail

La fonction `supabase/functions/send-stock-alerts/index.ts` utilise Resend. Crée un compte et vérifie le domaine/adresse expéditrice selon les règles actuelles de Resend : https://resend.com/.

Installer la CLI Supabase selon le guide officiel : https://supabase.com/docs/guides/cli puis se connecter et lier le projet. Déployer la fonction :

```bash
supabase login
supabase link --project-ref VOTRE_PROJECT_REF
supabase functions deploy send-stock-alerts
supabase functions deploy manage-users
supabase secrets set RESEND_API_KEY=VOTRE_CLE_RESEND ALERT_FROM_EMAIL="Mon Stock <stock@votre-domaine.fr>" APP_BASE_URL="https://URL-DE-L-APPLICATION"
```

`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` et `SUPABASE_ANON_KEY` sont généralement injectés par l'environnement Supabase des Edge Functions. Vérifie les secrets disponibles dans le projet. **Ne mets jamais `SUPABASE_SERVICE_ROLE_KEY` dans le fichier `.env` du frontend.**

Le bouton de test appelle la fonction. Pour envoyer les alertes en arrière-plan même quand aucun utilisateur n'a l'application ouverte, configure un appel programmé de la fonction (par exemple via Supabase Cron/pg_cron ou un ordonnanceur externe) avec une authentification serveur sécurisée. Un modèle prêt à l'emploi est fourni dans `supabase/schedule-alerts.sql` (secret `CRON_SECRET` à définir avec `supabase secrets set`).

## 3. Tester

```bash
npm test
npm run build
```

Les tests fournis vérifient quelques règles unitaires de calcul. Ils ne remplacent pas des tests d'intégration avec PostgreSQL/Supabase, des tests de permissions RLS, des tests multi-utilisateurs ni un test d'envoi e-mail réel.

## Structure

```text
src/
  App.jsx                 Interface et interactions
  main.jsx                Point d'entrée React
  styles.css              Styles responsives
public/
  manifest.webmanifest    Métadonnées PWA
  sw.js                   Cache minimal des fichiers statiques
supabase/
  migrations/              Schéma SQL et sécurité
  functions/send-stock-alerts/index.ts
                           Envoi des alertes via Resend
 tests/
  stock-rules.test.js      Tests unitaires de règles de base
.env.example               Variables frontend publiques uniquement
```

## Import du catalogue

Colonnes : `code_barres, reference_interne, designation, emplacement, stock_initial, seuil_minimum, quantite_a_commander, email_responsable, actif`. Les lignes avec `actif = non` sont ignorées.

Un modèle Excel séparé accompagne ce projet. Vérifie les codes-barres, conserve-les comme texte pour ne pas perdre les zéros initiaux, et vérifie les stocks physiquement avant le chargement. L'import CSV se fait dans l'onglet **Catalogue** (colonne `email_responsable` ignorée : les destinataires se règlent dans Réglages).

## Limites connues à traiter avant une utilisation réelle

- Le flux d’invitation et d’administration des comptes est amorcé, mais doit être testé de bout en bout avec les e-mails d’invitation et les permissions réelles.
- Un produit archivé n'est plus visible dans l'application ; pour le réactiver : `update public.products set active = true where sku = '...';` dans le SQL Editor.
- L'envoi des alertes doit être planifié côté serveur et surveillé ; le simple déploiement de la fonction ne suffit pas à lancer un traitement périodique.
- Le fournisseur d'e-mail, son domaine expéditeur et les limites de son plan doivent être validés.
- Le code frontend doit faire l'objet d'une revue sécurité, de tests réels et d'une validation des politiques RLS avant de stocker des données réelles.
- Les politiques SQL doivent être revues par un développeur avant une mise en production. Ne pas importer de stock réel avant cette validation.
- Le cache PWA ne stocke pas les mouvements hors ligne. Les mouvements nécessitent une connexion et une confirmation serveur.

## Déploiement frontend

Le frontend peut être hébergé sur un service statique compatible Vite (par exemple Vercel, Netlify ou Supabase Hosting si adapté). Définir `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` dans les variables de build du fournisseur, puis construire avec `npm run build`. Le dossier de sortie est `dist/`. Le site doit être servi en HTTPS pour le scan caméra sur les téléphones.

## Sécurité

- Aucun secret serveur dans le frontend.
- Les rôles sont stockés dans `profiles`; seuls les administrateurs doivent modifier les droits.
- Les mouvements passent par `record_stock_movement`, qui verrouille la ligne produit pendant le calcul.
- Toujours activer l'authentification multi-facteur pour les comptes administrateurs lorsque disponible.
- Faire des sauvegardes et tester la restauration avant la mise en production.
