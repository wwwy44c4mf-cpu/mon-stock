import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateMovement } from '../src/lib/stock.js';
import { parseCsv, catalogueFromRows, productsToCsv } from '../src/lib/csv.js';

test('sortie de 1 par défaut', () => assert.deepEqual(calculateMovement(10, 'sortie', 1), { after: 9, delta: -1 }));
test('sortie de quantité saisie', () => assert.equal(calculateMovement(20, 'sortie', 12).after, 8));
test('entrée', () => assert.deepEqual(calculateMovement(8, 'entree', 5), { after: 13, delta: 5 }));
test('refuse une sortie supérieure au stock', () => assert.throws(() => calculateMovement(3, 'sortie', 4), /insufficient stock/));
test('refuse zéro et non entier', () => { assert.throws(() => calculateMovement(3, 'sortie', 0), /invalid quantity/); assert.throws(() => calculateMovement(3, 'sortie', 1.5), /invalid quantity/); });
test('correction à la baisse (comptage)', () => assert.deepEqual(calculateMovement(10, 'correction', 7), { after: 7, delta: -3 }));
test('correction à la hausse et à zéro', () => { assert.equal(calculateMovement(5, 'correction', 9).delta, 4); assert.equal(calculateMovement(5, 'correction', 0).after, 0); });
test('correction identique refusée', () => assert.throws(() => calculateMovement(5, 'correction', 5), /no change/));

test('parse CSV avec guillemets, point-virgule et BOM', () => {
  const rows = parseCsv('\uFEFFa;b\r\n"x;y";"il dit ""oui"""\r\n');
  assert.deepEqual(rows, [['a', 'b'], ['x;y', 'il dit "oui"']]);
});
const header = 'code_barres,reference_interne,designation,emplacement,stock_initial,seuil_minimum,quantite_a_commander,email_responsable,actif';
test('import : le fichier exemple est valide et conserve les zéros du code-barres', () => {
  const { products, errors } = catalogueFromRows(parseCsv(`${header}\n0370012345678,VIS-1,Vis,A1,200,20,100,x@y.fr,oui\n,GANT,Gants,B3,50,10,50,x@y.fr,non`));
  assert.deepEqual(errors, []);
  assert.equal(products[0].barcode, '0370012345678');
  assert.equal(products[1].barcode, null);
  assert.equal(products[1].active, false);
});
test('import : erreurs détectées avec numéro de ligne', () => {
  const { products, errors } = catalogueFromRows(parseCsv(`${header}\n3.7E+12,A,Vis,,1,1,1,,oui\n,A,Doublon,,-2,1,1,,oui\n,B,,,1,1,1,,oui`));
  assert.equal(products.length, 0);
  assert.equal(errors.length, 3);
  assert.match(errors[0], /Ligne 2.*notation scientifique/);
  assert.match(errors[1], /Ligne 3.*stock initial invalide/);
  assert.match(errors[2], /Ligne 4.*désignation vide/);
});
test('import : colonnes obligatoires manquantes', () => assert.match(catalogueFromRows(parseCsv('a,b\n1,2')).errors[0], /manquantes/));
test('export CSV échappe les guillemets', () => assert.match(productsToCsv([{ barcode: null, sku: 'A', name: 'Vis "inox"', location: '', current_stock: 1, min_stock: 0, reorder_quantity: 0 }]), /"Vis ""inox"""/));
