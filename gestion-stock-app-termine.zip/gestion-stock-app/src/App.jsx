import { useEffect, useMemo, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { createClient } from '@supabase/supabase-js';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { AlertTriangle, ArrowDownCircle, ArrowUpCircle, Boxes, Camera, Check, ChevronRight, CircleHelp, ClipboardList, Download, LogOut, Mail, Package, Plus, RefreshCw, Search, Settings, Shield, Upload, Users, X } from 'lucide-react';
import { calculateMovement } from './lib/stock.js';
import { parseCsv, catalogueFromRows, productsToCsv } from './lib/csv.js';

// Lu avant que Supabase ne nettoie l'URL : lien d'invitation / de réinitialisation.
const initialHash = typeof window !== 'undefined' ? window.location.hash : '';
const needsPassword = /type=(invite|recovery)/.test(initialHash);
const linkExpired = /error_code=otp_expired|error=access_denied/.test(initialHash);

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const emptyProduct = { barcode: '', sku: '', name: '', location: '', initial_stock: 0, min_stock: 0, reorder_quantity: 0, active: true };
const errorText = (error) => error?.message || 'Une erreur inattendue est survenue.';

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [products, setProducts] = useState([]);
  const [moves, setMoves] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [recipients, setRecipients] = useState([]);
  const [users, setUsers] = useState([]);
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserName, setNewUserName] = useState('');
  const [tab, setTab] = useState('scan');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState(linkExpired ? 'Ce lien a expiré ou a déjà été utilisé. Utilise « Mot de passe oublié ? » ou demande une nouvelle invitation.' : '');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [quantity, setQuantity] = useState('1');
  const [moveType, setMoveType] = useState('sortie');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [productForm, setProductForm] = useState(emptyProduct);
  const [showProductForm, setShowProductForm] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [cameraOn, setCameraOn] = useState(false);
  const [recovery, setRecovery] = useState(needsPassword);
  const [newPassword, setNewPassword] = useState('');
  const [reason, setReason] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [importPreview, setImportPreview] = useState(null);
  const videoRef = useRef(null);
  const controlsRef = useRef(null);
  const isConfigured = Boolean(supabase);
  const isAdmin = profile?.role === 'admin';
  const canManage = isAdmin || profile?.permissions?.manage_products;
  const canStock = isAdmin || profile?.permissions?.manage_stock;

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((event, newSession) => { if (event === 'PASSWORD_RECOVERY') setRecovery(true); setSession(newSession); });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user) loadAll();
    else { setProfile(null); setProducts([]); setMoves([]); setAlerts([]); setRecipients([]); setUsers([]); }
  }, [session?.user?.id]);

  async function loadAll() {
    if (!supabase) return;
    setBusy(true); setError('');
    try {
      const [p, prod, mov, al, rec] = await Promise.all([
        supabase.from('profiles').select('id, display_name, role, permissions').eq('id', session.user.id).single(),
        supabase.from('products').select('*').eq('active', true).order('name'),
        supabase.from('stock_movements').select('id, product_id, movement_type, quantity, delta, reason, created_at, actor_id, products(name, sku, barcode), profiles(display_name)').order('created_at', { ascending: false }).limit(100),
        supabase.from('stock_alerts').select('id, product_id, status, stock_at_alert, created_at, products(name, sku)').order('created_at', { ascending: false }).limit(50),
        supabase.from('alert_recipients').select('*').order('email')
      ]);
      if (p.error) throw p.error;
      if (prod.error) throw prod.error;
      if (mov.error) throw mov.error;
      if (al.error) throw al.error;
      if (rec.error) throw rec.error;
      setProfile(p.data); setProducts(prod.data || []); setMoves(mov.data || []); setAlerts(al.data || []); setRecipients(rec.data || []);
      if (p.data.role === 'admin') { const { data: allUsers, error: usersError } = await supabase.from('profiles').select('id, display_name, role, active, permissions, created_at').order('created_at'); if (usersError) throw usersError; setUsers(allUsers || []); } else setUsers([]);
    } catch (e) { setError(`Chargement impossible : ${errorText(e)}`); }
    finally { setBusy(false); }
  }

  async function signIn(e) {
    e.preventDefault(); setBusy(true); setError('');
    const { error: authError } = await supabase.auth.signInWithPassword({ email: loginEmail.trim(), password: loginPassword });
    if (authError) setError(errorText(authError));
    setBusy(false);
  }
  async function signOut() { setRecovery(false); await supabase.auth.signOut(); }
  async function resetPassword() {
    if (!loginEmail.trim()) { setError('Saisis ton adresse e-mail ci-dessus, puis clique sur « Mot de passe oublié ? ».'); return; }
    setBusy(true); setError(''); setMessage('');
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(loginEmail.trim(), { redirectTo: window.location.origin });
    if (resetError) setError(errorText(resetError)); else setMessage('Si ce compte existe, un e-mail de réinitialisation vient d’être envoyé.');
    setBusy(false);
  }
  async function savePassword(e) {
    e.preventDefault();
    if (newPassword.length < 8) { setError('Le mot de passe doit contenir au moins 8 caractères.'); return; }
    setBusy(true); setError('');
    const { error: upError } = await supabase.auth.updateUser({ password: newPassword });
    if (upError) setError(errorText(upError));
    else { setRecovery(false); setNewPassword(''); window.history.replaceState(null, '', window.location.pathname); setMessage('Mot de passe enregistré. Bienvenue !'); }
    setBusy(false);
  }

  function selectProduct(product) { setSelected(product); setReason(''); setQuantity('1'); setMoveType('sortie'); setTab('scan'); setMessage(''); setError(''); }
  async function lookupBarcode(raw) {
    const barcode = String(raw || '').trim();
    if (!barcode) return;
    setError(''); setMessage('');
    const match = products.find(p => p.barcode === barcode || p.sku?.toLowerCase() === barcode.toLowerCase());
    if (match) selectProduct(match);
    else {
      const { data, error: lookupError } = await supabase.from('products').select('*').eq('barcode', barcode).eq('active', true).maybeSingle();
      if (lookupError) setError(errorText(lookupError));
      else if (data) selectProduct(data);
      else { setQuery(barcode); setTab('products'); setError(`Aucune référence trouvée pour le code « ${barcode} ». Vérifie le code ou ajoute la référence si tu en as le droit.`); }
    }
  }
  async function startCamera() {
    if (!navigator.mediaDevices?.getUserMedia) { setError('La caméra n’est pas disponible dans ce navigateur. Essaie une connexion HTTPS ou utilise la recherche manuelle.'); return; }
    flushSync(() => setCameraOn(true)); setError('');
    try {
      const reader = new BrowserMultiFormatReader();
      const controls = await reader.decodeFromConstraints({ video: { facingMode: 'environment' } }, videoRef.current, (result) => {
        if (result) { controlsRef.current?.stop(); controlsRef.current = null; setCameraOn(false); lookupBarcode(result.getText()); }
      });
      controlsRef.current = controls;
    } catch (e) { setCameraOn(false); setError(`Impossible de démarrer la caméra : ${errorText(e)}. Vérifie l’autorisation caméra et le HTTPS.`); }
  }
  function stopCamera() { controlsRef.current?.stop(); controlsRef.current = null; setCameraOn(false); }
  useEffect(() => () => { controlsRef.current?.stop(); }, []);

  async function saveMovement(e) {
    e.preventDefault();
    if (!selected) return;
    const qty = Number(quantity);
    if (!Number.isSafeInteger(qty) || qty < 0 || (moveType !== 'correction' && qty === 0)) { setError(moveType === 'correction' ? 'Saisis le stock constaté (entier, zéro autorisé).' : 'Saisis une quantité entière supérieure à zéro.'); return; }
    if (moveType === 'correction' && !reason.trim()) { setError('Un motif est obligatoire pour une correction.'); return; }
    setBusy(true); setError(''); setMessage('');
    try {
      const { data, error: rpcError } = await supabase.rpc('record_stock_movement', {
        p_product_id: selected.id,
        p_movement_type: moveType,
        p_quantity: qty,
        p_reason: moveType === 'correction' ? reason.trim() : null
      });
      if (rpcError) throw rpcError;
      setMessage(data?.message || 'Mouvement enregistré.'); setSelected(null); await loadAll();
    } catch (e2) { setError(errorText(e2)); }
    finally { setBusy(false); }
  }

  async function saveProduct(e) {
    e.preventDefault(); setBusy(true); setError(''); setMessage('');
    try {
      const fields = { barcode: productForm.barcode.trim() || null, sku: productForm.sku.trim(), name: productForm.name.trim(), location: productForm.location.trim(), min_stock: Number(productForm.min_stock), reorder_quantity: Number(productForm.reorder_quantity) };
      const initial = Number(productForm.initial_stock);
      const numbers = editingId ? [fields.min_stock, fields.reorder_quantity] : [fields.min_stock, fields.reorder_quantity, initial];
      if (numbers.some(n => !Number.isSafeInteger(n) || n < 0)) throw new Error('Les quantités doivent être des entiers positifs ou nuls.');
      const { error: saveError } = editingId
        ? await supabase.from('products').update(fields).eq('id', editingId)
        : await supabase.from('products').insert({ ...fields, initial_stock: initial, current_stock: initial, created_by: session.user.id });
      if (saveError) throw saveError;
      const wasEditing = Boolean(editingId); closeProductForm(); setMessage(wasEditing ? 'Référence modifiée.' : 'Référence créée.'); await loadAll();
    } catch (e) { setError(errorText(e)); }
    finally { setBusy(false); }
  }
  function closeProductForm() { setShowProductForm(false); setEditingId(null); setProductForm(emptyProduct); }
  function startEdit(p) { setEditingId(p.id); setProductForm({ barcode: p.barcode || '', sku: p.sku, name: p.name, location: p.location || '', initial_stock: p.initial_stock, min_stock: p.min_stock, reorder_quantity: p.reorder_quantity, active: true }); setShowProductForm(true); setSelected(null); setTab('products'); setError(''); setMessage(''); }
  async function archiveProduct() {
    if (!editingId || !confirm('Archiver cette référence ? Elle disparaîtra du catalogue (l’historique est conservé).')) return;
    setBusy(true); setError('');
    const { error: archiveError } = await supabase.from('products').update({ active: false }).eq('id', editingId);
    if (archiveError) setError(errorText(archiveError)); else { closeProductForm(); setMessage('Référence archivée.'); await loadAll(); }
    setBusy(false);
  }
  async function importFile(e) {
    const file = e.target.files?.[0]; e.target.value = ''; if (!file) return;
    setError(''); setMessage(''); setBusy(true);
    try {
      const parsed = catalogueFromRows(parseCsv(await file.text()));
      const errors = [...parsed.errors];
      if (!errors.length) {
        for (let i = 0; i < parsed.products.length; i += 100) {
          const chunk = parsed.products.slice(i, i + 100);
          const codes = chunk.map(p => p.barcode).filter(Boolean);
          const [bySku, byCode] = await Promise.all([supabase.from('products').select('sku').in('sku', chunk.map(p => p.sku)), codes.length ? supabase.from('products').select('barcode').in('barcode', codes) : Promise.resolve({ data: [] })]);
          if (bySku.error) throw bySku.error; if (byCode.error) throw byCode.error;
          (bySku.data || []).forEach(r => errors.push(`La référence « ${r.sku} » existe déjà dans le catalogue.`));
          (byCode.data || []).forEach(r => errors.push(`Le code-barres « ${r.barcode} » existe déjà dans le catalogue.`));
        }
      }
      setImportPreview({ name: file.name, products: parsed.products, errors });
    } catch (err) { setError(errorText(err)); } finally { setBusy(false); }
  }
  async function runImport() {
    const rows = importPreview.products.filter(p => p.active).map(({ active, ...p }) => ({ ...p, current_stock: p.initial_stock, created_by: session.user.id }));
    if (!rows.length) return;
    setBusy(true); setError(''); setMessage('');
    let done = 0;
    try {
      for (let i = 0; i < rows.length; i += 100) {
        const { error: insertError } = await supabase.from('products').insert(rows.slice(i, i + 100));
        if (insertError) throw insertError;
        done += Math.min(100, rows.length - i);
      }
      setImportPreview(null); setMessage(`${done} référence(s) importée(s).`);
    } catch (err) { setError(`Import interrompu après ${done} référence(s) : ${errorText(err)}`); }
    finally { setBusy(false); await loadAll(); }
  }
  function exportCsv() {
    const url = URL.createObjectURL(new Blob([productsToCsv(products)], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = `catalogue-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); URL.revokeObjectURL(url);
  }
  async function addRecipient(e) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const email = recipientEmail.trim().toLowerCase();
      const { error: saveError } = await supabase.from('alert_recipients').insert({ email, active: true });
      if (saveError) throw saveError;
      setRecipientEmail(''); setMessage('Destinataire ajouté.'); await loadAll();
    } catch (e) { setError(errorText(e)); }
    finally { setBusy(false); }
  }
  async function removeRecipient(id) {
    if (!confirm('Retirer ce destinataire des alertes ?')) return;
    const { error: deleteError } = await supabase.from('alert_recipients').delete().eq('id', id);
    if (deleteError) setError(errorText(deleteError)); else await loadAll();
  }
  async function testEmail() {
    setBusy(true); setError(''); setMessage('');
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('send-stock-alerts', { body: { test: true } });
      if (invokeError) throw invokeError;
      setMessage(data?.message || 'Demande de test envoyée. Vérifie la boîte de réception et les indésirables.');
    } catch (e) { setError(`Test e-mail impossible : ${errorText(e)}. Vérifie que la fonction d’e-mail est déployée et configurée.`); }
    finally { setBusy(false); }
  }

  async function inviteUser(e) {
    e.preventDefault(); setBusy(true); setError(''); setMessage('');
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('manage-users', { body: { action: 'invite', email: newUserEmail.trim(), display_name: newUserName.trim() } });
      if (invokeError) throw invokeError;
      if (data?.error) throw new Error(data.error);
      setMessage(data?.message || 'Invitation envoyée.'); setNewUserEmail(''); setNewUserName(''); await loadAll();
    } catch (e) { setError(`Invitation impossible : ${errorText(e)}. Vérifie que la fonction manage-users est déployée.`); }
    finally { setBusy(false); }
  }
  async function updateUser(id, changes) {
    setBusy(true); setError(''); setMessage('');
    try {
      const { error: updateError } = await supabase.from('profiles').update(changes).eq('id', id);
      if (updateError) throw updateError;
      setMessage('Compte utilisateur mis à jour.'); await loadAll();
    } catch (e) { setError(errorText(e)); }
    finally { setBusy(false); }
  }

  const filteredProducts = useMemo(() => products.filter(p => `${p.name} ${p.sku} ${p.barcode} ${p.location}`.toLowerCase().includes(query.toLowerCase())), [products, query]);
  const lowStock = products.filter(p => p.current_stock <= p.min_stock);
  const movePreview = (() => { if (!selected) return null; try { return calculateMovement(selected.current_stock, moveType, Number(quantity)); } catch { return null; } })();
  const movementCountToday = moves.filter(m => new Date(m.created_at).toDateString() === new Date().toDateString()).length;

  if (!isConfigured) return <SetupScreen />;
  if (session && recovery) return <main className="auth-wrap"><div className="brand-mark"><Boxes size={28}/></div><h1>Mon Stock</h1><form className="panel auth-panel" onSubmit={savePassword}><h2>Choisis ton mot de passe</h2><label>Nouveau mot de passe (8 caractères minimum)<input type="password" autoComplete="new-password" required minLength={8} value={newPassword} onChange={e => setNewPassword(e.target.value)}/></label><button className="primary full" disabled={busy}>{busy ? 'Enregistrement…' : 'Enregistrer et continuer'}</button>{error && <p className="error">{error}</p>}</form></main>;
  if (!session) return <main className="auth-wrap"><div className="brand-mark"><Boxes size={28}/></div><h1>Mon Stock</h1><p className="muted">Gestion de stock partagée</p><form className="panel auth-panel" onSubmit={signIn}><h2>Connexion</h2><label>Adresse e-mail<input type="email" autoComplete="username" required value={loginEmail} onChange={e => setLoginEmail(e.target.value)}/></label><label>Mot de passe<input type="password" autoComplete="current-password" required value={loginPassword} onChange={e => setLoginPassword(e.target.value)}/></label><button className="primary full" disabled={busy}>{busy ? 'Connexion…' : 'Se connecter'}</button><button type="button" className="text-button" onClick={resetPassword} disabled={busy}>Mot de passe oublié ?</button>{message && <p className="hint">{message}</p>}{error && <p className="error">{error}</p>}</form></main>;

  return <div className="app-shell">
    <header className="topbar"><div className="brand"><span className="brand-mark small"><Boxes size={21}/></span><div><strong>Mon Stock</strong><small>{profile?.display_name || session.user.email}</small></div></div><button className="icon-button" title="Se déconnecter" onClick={signOut}><LogOut size={19}/></button></header>
    <main className="main-content">
      <section className="welcome"><div><p className="eyebrow">ESPACE DE TRAVAIL</p><h1>Bonjour{profile?.display_name ? ` ${profile.display_name}` : ''}</h1><p className="muted">Voici l’état de ton stock.</p></div><button className="secondary refresh" onClick={loadAll} disabled={busy}><RefreshCw size={16}/> Actualiser</button></section>
      {error && <div className="notice error-notice"><AlertTriangle size={18}/><span>{error}</span><button onClick={() => setError('')}><X size={16}/></button></div>}
      {message && <div className="notice success-notice"><Check size={18}/><span>{message}</span><button onClick={() => setMessage('')}><X size={16}/></button></div>}
      <section className="stats-grid"><Stat icon={<Package/>} label="Références actives" value={products.length}/><Stat icon={<ClipboardList/>} label="Mouvements aujourd’hui" value={movementCountToday}/><Stat icon={<AlertTriangle/>} label="Stocks à surveiller" value={lowStock.length} warn={lowStock.length > 0}/></section>
      <nav className="tabs" aria-label="Navigation principale">{[['scan',<Camera size={17}/>,'Scanner'],['products',<Package size={17}/>,'Produits'],['history',<ClipboardList size={17}/>,'Historique'],...((isAdmin || profile?.permissions?.manage_alerts) ? [['settings',<Settings size={17}/>,'Réglages']] : []),...(canManage ? [['import',<Upload size={17}/>,'Catalogue']] : [])].map(([id, icon, label]) => <button key={id} className={tab === id ? 'tab active' : 'tab'} onClick={() => {setTab(id); setSelected(null); setError('');}}>{icon}<span>{label}</span></button>)}</nav>
      {tab === 'scan' && <section className="content-grid"><div className="panel scan-panel"><div className="panel-heading"><div><h2>Sortie de matériel</h2><p className="muted">Scanne un code ou recherche une référence.</p></div><Camera size={23}/></div>{!selected ? <><button className="scan-button" onClick={startCamera}><Camera size={23}/><span>Ouvrir le scanner</span><ChevronRight size={18}/></button>{cameraOn && <div className="camera-wrap"><video ref={videoRef} muted playsInline/><button className="secondary full" onClick={stopCamera}>Fermer la caméra</button></div>}<div className="or-divider"><span>ou recherche manuelle</span></div><div className="search-field"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Code-barres, référence, désignation…"/></div><div className="quick-results">{filteredProducts.slice(0,5).map(p => <button className="product-result" key={p.id} onClick={() => selectProduct(p)}><span className="product-icon"><Package size={18}/></span><span className="result-copy"><strong>{p.name}</strong><small>{p.sku} · {p.location || 'Emplacement non renseigné'}</small></span><span className="stock-number">{p.current_stock}</span></button>)}</div></> : <form onSubmit={saveMovement} className="selected-product"><button type="button" className="text-button" onClick={() => setSelected(null)}>← Retour au scan</button><div className="selected-title"><div className="product-icon large"><Package size={25}/></div><div><h3>{selected.name}</h3><p className="muted">{selected.sku} · {selected.barcode || 'Sans code-barres'}</p></div></div><div className="stock-summary"><div><small>Stock disponible</small><strong>{selected.current_stock}</strong></div><div><small>Seuil minimum</small><strong>{selected.min_stock}</strong></div><div><small>Emplacement</small><strong className="location-value">{selected.location || '—'}</strong></div></div><label>Type de mouvement<select value={moveType} onChange={e => { setMoveType(e.target.value); setQuantity(e.target.value === 'correction' ? String(selected.current_stock) : '1'); }}><option value="sortie">Sortie de stock</option>{canStock && <option value="entree">Entrée de stock</option>}{canStock && <option value="correction">Correction (comptage)</option>}</select></label><label>{moveType === 'correction' ? 'Stock constaté (quantité réelle comptée)' : 'Quantité'}<input type="number" min={moveType === 'correction' ? 0 : 1} step="1" inputMode="numeric" value={quantity} onChange={e => setQuantity(e.target.value)} required/></label>{moveType === 'correction' && <label>Motif (obligatoire)<input value={reason} onChange={e => setReason(e.target.value)} placeholder="Inventaire, casse, erreur de saisie…" required/></label>}{movePreview && <p className="hint">Stock après opération : <b>{movePreview.after}</b> ({movePreview.delta > 0 ? '+' : '−'}{Math.abs(movePreview.delta)})</p>}<button className="primary full" disabled={busy}>{busy ? 'Enregistrement…' : `Confirmer ${({ sortie: 'la sortie', entree: 'l’entrée', correction: 'la correction' })[moveType]}`}</button>{canManage && <button type="button" className="text-button" onClick={() => startEdit(selected)}>Modifier la fiche produit</button>}<p className="hint">Le mouvement n’est confirmé qu’après validation par le serveur.</p></form>}</div><div className="panel low-panel"><div className="panel-heading"><div><h2>À réapprovisionner</h2><p className="muted">Stock inférieur ou égal au seuil.</p></div><AlertTriangle size={21}/></div>{lowStock.length === 0 ? <div className="empty-state"><Check size={24}/><strong>Aucune alerte de stock</strong><p>Tous les produits sont au-dessus de leur seuil.</p></div> : lowStock.slice(0,8).map(p => <button key={p.id} className="low-item" onClick={() => selectProduct(p)}><span><strong>{p.name}</strong><small>Seuil : {p.min_stock} · Commander : {p.reorder_quantity}</small></span><b>{p.current_stock}</b></button>)}</div></section>}
      {tab === 'products' && <section className="panel"><div className="panel-heading"><div><h2>Catalogue produits</h2><p className="muted">{products.length} référence(s) active(s)</p></div>{canManage && <button className="primary compact" onClick={() => { if (showProductForm) closeProductForm(); else setShowProductForm(true); }}><Plus size={16}/> Ajouter</button>}</div><div className="search-field"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher un produit…"/></div>{showProductForm && <form className="product-form" onSubmit={saveProduct}><h3>{editingId ? 'Modifier la référence' : 'Nouvelle référence'}</h3><div className="form-grid"><label>Code-barres<input value={productForm.barcode} onChange={e => setProductForm({...productForm, barcode:e.target.value})} placeholder="Code lu sur le produit"/></label><label>Référence interne<input required value={productForm.sku} onChange={e => setProductForm({...productForm, sku:e.target.value})}/></label><label className="span-2">Désignation<input required value={productForm.name} onChange={e => setProductForm({...productForm, name:e.target.value})}/></label><label>Emplacement<input value={productForm.location} onChange={e => setProductForm({...productForm, location:e.target.value})}/></label>{!editingId && <label>Stock initial<input type="number" min="0" step="1" required value={productForm.initial_stock} onChange={e => setProductForm({...productForm, initial_stock:e.target.value})}/></label>}<label>Seuil minimum<input type="number" min="0" step="1" required value={productForm.min_stock} onChange={e => setProductForm({...productForm, min_stock:e.target.value})}/></label><label>Quantité à commander<input type="number" min="0" step="1" required value={productForm.reorder_quantity} onChange={e => setProductForm({...productForm, reorder_quantity:e.target.value})}/></label></div><div className="form-actions">{editingId && <button type="button" className="secondary danger-text" onClick={archiveProduct} disabled={busy}>Archiver</button>}<button type="button" className="secondary" onClick={closeProductForm}>Annuler</button><button className="primary" disabled={busy}>Enregistrer</button></div></form>}<div className="table-list">{filteredProducts.map(p => <button key={p.id} className="product-row" onClick={() => selectProduct(p)}><span className="product-icon"><Package size={18}/></span><span className="result-copy"><strong>{p.name}</strong><small>{p.sku} · {p.barcode || 'Pas de code-barres'} · {p.location || 'Emplacement —'}</small></span><span className={p.current_stock <= p.min_stock ? 'stock-number low' : 'stock-number'}>{p.current_stock}</span><ChevronRight size={17}/></button>)}</div>{filteredProducts.length === 0 && <p className="empty-state">Aucun produit trouvé.</p>}</section>}
      {tab === 'history' && <section className="panel"><div className="panel-heading"><div><h2>Historique des mouvements</h2><p className="muted">Les 100 derniers mouvements.</p></div><ClipboardList size={22}/></div>{moves.length === 0 ? <div className="empty-state"><ClipboardList size={24}/><p>Aucun mouvement enregistré pour le moment.</p></div> : <div className="table-list">{moves.map(m => <div className="history-row" key={m.id}><span className={`movement-icon ${m.movement_type}`} >{m.delta < 0 ? <ArrowDownCircle size={19}/> : <ArrowUpCircle size={19}/>}</span><span className="result-copy"><strong>{m.products?.name || 'Produit archivé'}</strong><small>{m.movement_type === 'correction' ? `Correction (${m.reason}) · ` : ''}{m.profiles?.display_name || 'Utilisateur'} · {new Date(m.created_at).toLocaleString('fr-FR')}</small></span><b className={m.delta < 0 ? 'qty-out' : 'qty-in'}>{m.delta < 0 ? '−' : '+'}{Math.abs(m.delta)}</b></div>)}</div>}</section>}
      {tab === 'import' && canManage && <section className="panel"><div className="panel-heading"><div><h2>Import / export du catalogue</h2><p className="muted">CSV avec les colonnes du modèle <code>catalogue-exemple.csv</code>.</p></div><Upload size={22}/></div><label className="file-label"><Upload size={18}/> Choisir un fichier CSV<input type="file" accept=".csv,text/csv" onChange={importFile} disabled={busy}/></label>{importPreview && <div className="import-preview"><strong>{importPreview.name}</strong>{importPreview.errors.length === 0 ? <p className="hint">{importPreview.products.filter(p => p.active).length} référence(s) prête(s) à importer{importPreview.products.some(p => !p.active) ? ` · ${importPreview.products.filter(p => !p.active).length} ignorée(s) (actif = non)` : ''}. Le stock initial sera enregistré comme mouvement « Stock initial ».</p> : <><p className="error">{importPreview.errors.length} problème(s) à corriger dans le fichier avant import :</p><ul className="error-list">{importPreview.errors.slice(0, 20).map((m, i) => <li key={i}>{m}</li>)}{importPreview.errors.length > 20 && <li>… et {importPreview.errors.length - 20} autre(s).</li>}</ul></>}<div className="form-actions"><button className="secondary" onClick={() => setImportPreview(null)}>Annuler</button><button className="primary" disabled={busy || importPreview.errors.length > 0 || !importPreview.products.some(p => p.active)} onClick={runImport}>{busy ? 'Import…' : 'Importer'}</button></div></div>}<button className="secondary full top-gap" onClick={exportCsv}><Download size={17}/> Exporter le catalogue (CSV)</button><p className="hint">Excel supprime les zéros initiaux des codes-barres si tu ouvres le CSV par double-clic : importe-le via « Données → À partir d’un fichier texte » en colonne Texte.</p></section>}
      {tab === 'settings' && (isAdmin || profile?.permissions?.manage_alerts) && <section className="settings-grid"><div className="panel"><div className="panel-heading"><div><h2>Destinataires des alertes</h2><p className="muted">Les personnes qui reçoivent les alertes de réapprovisionnement.</p></div><Mail size={22}/></div><form className="inline-form" onSubmit={addRecipient}><input type="email" required placeholder="nom@entreprise.fr" value={recipientEmail} onChange={e => setRecipientEmail(e.target.value)}/><button className="primary" disabled={busy}><Plus size={16}/> Ajouter</button></form>{recipients.map(r => <div className="recipient-row" key={r.id}><span><Mail size={17}/>{r.email}</span><button className="icon-button danger" onClick={() => removeRecipient(r.id)} title="Retirer"><X size={17}/></button></div>)}{recipients.length === 0 && <p className="hint">Aucun destinataire configuré.</p>}<button className="secondary full top-gap" onClick={testEmail} disabled={busy}><Mail size={17}/> Envoyer un e-mail de test</button></div>{isAdmin && <div className="panel"><div className="panel-heading"><div><h2>Administration</h2><p className="muted">Comptes et permissions</p></div><Users size={22}/></div><div className="admin-info"><strong>Compte connecté</strong><span>{session.user.email}</span><strong>Rôle</strong><span>{profile?.role === 'admin' ? 'Administrateur principal' : profile?.role === 'manager' ? 'Gestionnaire' : 'Utilisateur'}</span></div><form className="user-invite-form" onSubmit={inviteUser}><h3>Inviter une personne</h3><label>Nom affiché<input value={newUserName} onChange={e => setNewUserName(e.target.value)} placeholder="Prénom Nom"/></label><label>Adresse e-mail<input type="email" required value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} placeholder="personne@entreprise.fr"/></label><button className="primary full" disabled={busy}>Envoyer une invitation</button><p className="hint">La personne reçoit une invitation pour créer son compte. Le rôle initial est utilisateur standard.</p></form><h3 className="users-heading">Comptes existants</h3>{users.map(u => <div className="user-row" key={u.id}><div className="user-row-copy"><strong>{u.display_name || 'Utilisateur'}</strong><small>{u.id === session.user.id ? 'Ton compte' : u.role === 'admin' ? 'Administrateur' : u.role === 'manager' ? 'Gestionnaire' : 'Utilisateur standard'} · {u.active ? 'Actif' : 'Désactivé'}</small></div>{u.id !== session.user.id && <div className="user-actions"><select aria-label="Rôle utilisateur" value={u.role} onChange={e => updateUser(u.id, { role: e.target.value })}><option value="user">Utilisateur</option><option value="manager">Gestionnaire</option></select><button className="secondary user-toggle" onClick={() => updateUser(u.id, { active: !u.active })}>{u.active ? 'Désactiver' : 'Activer'}</button></div>}<div className="permission-list">{u.id !== session.user.id && [['manage_products','Gérer les références'],['manage_stock','Gérer les entrées et corrections'],['manage_users','Consulter les comptes'],['manage_alerts','Gérer les alertes']].map(([key,label]) => <label key={key}><input type="checkbox" checked={Boolean(u.permissions?.[key])} onChange={e => updateUser(u.id, { permissions: { ...(u.permissions || {}), [key]: e.target.checked } })}/><span>{label}</span></label>)}</div></div>)}<p className="hint top-gap">Ne partage jamais la clé secrète Supabase ou la clé du service e-mail. Les rôles et statuts sont contrôlés dans la base de données.</p><a className="external-link" href="https://supabase.com/dashboard" target="_blank" rel="noreferrer">Ouvrir le tableau de bord Supabase <ChevronRight size={16}/></a></div>}</section>}
      <footer><span>Mon Stock · Première version</span><span>{busy ? 'Synchronisation…' : 'Données synchronisées'}</span></footer>
    </main>
  </div>;
}

function Stat({ icon, label, value, warn }) { return <div className={`stat-card ${warn ? 'stat-warn' : ''}`}><span className="stat-icon">{icon}</span><div><strong>{value}</strong><small>{label}</small></div></div>; }
function SetupScreen() { return <main className="setup-wrap"><div className="brand-mark"><Boxes size={28}/></div><h1>Mon Stock</h1><p className="muted">La configuration du projet n'est pas terminée.</p><div className="panel setup-panel"><h2>Connexion à Supabase requise</h2><p>Pour démarrer, crée un fichier <code>.env</code> à la racine du projet à partir de <code>.env.example</code>, puis renseigne l'URL du projet Supabase et sa clé publique (anon/publishable).</p><ol><li>Crée ton projet Supabase.</li><li>Ouvre <b>Project Settings → API</b>.</li><li>Copie l'URL et la clé publique dans le fichier <code>.env</code>.</li><li>Redémarre l'application avec <code>npm run dev</code>.</li></ol><div className="notice info-notice"><CircleHelp size={18}/><span>Ne mets jamais une clé secrète/service_role dans le frontend. Les règles SQL de sécurité doivent être appliquées avant d'importer des données réelles.</span></div></div></main>; }
