-- Mon Stock : migration 2. À appliquer APRÈS 202610130001_initial_schema.sql.
-- 1) Corrections signées (comptage d'inventaire)  2) stock modifiable uniquement via la RPC
-- 3) noms visibles dans l'historique pour tous les comptes actifs

-- Quantité signée dans l'historique (sortie = négatif, entrée = positif, correction = écart)
alter table public.stock_movements add column if not exists delta integer;
update public.stock_movements
   set delta = case when movement_type = 'sortie' then -quantity else quantity end
 where delta is null;
alter table public.stock_movements alter column delta set not null;

-- Lecture des profils (nom affiché) pour tout compte actif ; fonction security definer pour éviter la récursion RLS
create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.active) $$;
revoke all on function public.is_active_user() from public, anon;
grant execute on function public.is_active_user() to authenticated;

drop policy if exists "profiles_read_self_or_admin" on public.profiles;
create policy "profiles_read_active_users" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_active_user());

-- Interdit de modifier current_stock autrement que par record_stock_movement
create or replace function public.guard_stock_changes()
returns trigger language plpgsql set search_path = public
as $$
begin
  if new.current_stock is distinct from old.current_stock
     and coalesce(current_setting('app.stock_rpc', true), '') <> '1' then
    raise exception 'Le stock ne peut être modifié que par un mouvement enregistré.' using errcode = '42501';
  end if;
  return new;
end;
$$;
drop trigger if exists products_guard_stock on public.products;
create trigger products_guard_stock before update of current_stock on public.products
  for each row execute procedure public.guard_stock_changes();

-- RPC : correction = stock constaté (comptage). p_quantity = nouveau stock total (>= 0) pour 'correction'
create or replace function public.record_stock_movement(
  p_product_id uuid,
  p_movement_type text,
  p_quantity integer,
  p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public
as $$
declare
  product_row public.products%rowtype;
  before_qty integer;
  after_qty integer;
  delta_qty integer;
begin
  if auth.uid() is null then raise exception 'Connexion requise.' using errcode = '28000'; end if;
  if not exists(select 1 from public.profiles where id = auth.uid() and active) then raise exception 'Compte inactif ou profil absent.'; end if;
  if p_movement_type not in ('sortie','entree','correction') then raise exception 'Type de mouvement invalide.'; end if;
  if p_quantity is null or p_quantity < 0 then raise exception 'La quantité doit être un entier positif.'; end if;
  if p_movement_type <> 'correction' and p_quantity = 0 then raise exception 'La quantité doit être supérieure à zéro.'; end if;
  if p_movement_type in ('entree','correction') and not public.has_permission('manage_stock') then raise exception 'Droits insuffisants pour cette opération.' using errcode = '42501'; end if;
  if p_movement_type = 'correction' and length(trim(coalesce(p_reason,''))) = 0 then raise exception 'Un motif est obligatoire pour une correction.'; end if;

  perform set_config('app.stock_rpc', '1', true);
  select * into product_row from public.products where id = p_product_id and active = true for update;
  if not found then raise exception 'Produit introuvable ou archivé.'; end if;
  before_qty := product_row.current_stock;

  if p_movement_type = 'sortie' then
    after_qty := before_qty - p_quantity;
    if after_qty < 0 then raise exception 'Stock insuffisant. Stock actuel : %.', before_qty; end if;
    delta_qty := -p_quantity;
  elsif p_movement_type = 'entree' then
    after_qty := before_qty + p_quantity;
    delta_qty := p_quantity;
  else
    after_qty := p_quantity;
    delta_qty := after_qty - before_qty;
    if delta_qty = 0 then raise exception 'Le stock constaté est identique au stock enregistré (%).', before_qty; end if;
  end if;

  update public.products set current_stock = after_qty where id = p_product_id;
  insert into public.stock_movements(product_id, movement_type, quantity, delta, stock_before, stock_after, reason, actor_id)
  values (p_product_id, p_movement_type, abs(delta_qty), delta_qty, before_qty, after_qty, nullif(trim(p_reason),''), auth.uid());
  insert into public.audit_log(actor_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'mouvement_stock', 'product', p_product_id,
          jsonb_build_object('type', p_movement_type, 'delta', delta_qty, 'avant', before_qty, 'apres', after_qty));
  return jsonb_build_object('message', 'Mouvement enregistré.', 'stock_before', before_qty, 'stock_after', after_qty);
end;
$$;
