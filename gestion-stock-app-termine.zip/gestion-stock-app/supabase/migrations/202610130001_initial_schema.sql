-- Mon Stock: schéma initial. Appliquer dans un projet Supabase vierge.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'user' check (role in ('admin','manager','user')),
  permissions jsonb not null default '{"manage_products":false,"manage_stock":false,"manage_users":false,"manage_alerts":false}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  barcode text unique,
  sku text not null unique,
  name text not null,
  location text not null default '',
  initial_stock integer not null default 0 check (initial_stock >= 0),
  current_stock integer not null default 0 check (current_stock >= 0),
  min_stock integer not null default 0 check (min_stock >= 0),
  reorder_quantity integer not null default 0 check (reorder_quantity >= 0),
  alert_armed boolean not null default true,
  active boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (length(trim(name)) > 0),
  check (barcode is null or length(trim(barcode)) > 0)
);

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  movement_type text not null check (movement_type in ('sortie','entree','correction')),
  quantity integer not null check (quantity > 0),
  stock_before integer not null check (stock_before >= 0),
  stock_after integer not null check (stock_after >= 0),
  reason text,
  actor_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create index stock_movements_created_at_idx on public.stock_movements(created_at desc);
create index stock_movements_product_idx on public.stock_movements(product_id, created_at desc);

create table public.alert_recipients (
  id uuid primary key default gen_random_uuid(),
  email text not null unique check (email = lower(trim(email)) and position('@' in email) > 1),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

create table public.stock_alerts (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  stock_at_alert integer not null check (stock_at_alert >= 0),
  attempts integer not null default 0,
  last_error text,
  sent_at timestamptz,
  created_at timestamptz not null default now()
);
create index stock_alerts_pending_idx on public.stock_alerts(status, created_at) where status in ('pending','failed');

create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_profile()
returns public.profiles language sql stable security definer set search_path = public
as $$ select p.* from public.profiles p where p.id = auth.uid() and p.active = true $$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.active and p.role = 'admin') $$;

create or replace function public.has_permission(permission_name text)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.active and (p.role = 'admin' or coalesce((p.permissions ->> permission_name)::boolean, false))) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''), 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.audit_profile_changes()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if (old.role is distinct from new.role) or (old.permissions is distinct from new.permissions) or (old.active is distinct from new.active) then
    -- Un gestionnaire ne peut pas s'attribuer des droits ou promouvoir un autre compte.
    -- auth.uid() est NULL lors d'une opération d'administration depuis le SQL Editor.
    if auth.uid() is not null and not public.is_admin() then
      raise exception 'Seul un administrateur principal peut modifier les rôles, permissions ou statuts des comptes.' using errcode = '42501';
    end if;
    if auth.uid() is not null and old.role <> 'admin' and new.role = 'admin' then
      raise exception 'Le compte administrateur principal ne peut pas être attribué depuis l’application.';
    end if;
    if old.role = 'admin' and old.active and (new.role <> 'admin' or not new.active)
       and not exists(select 1 from public.profiles p where p.id <> old.id and p.role = 'admin' and p.active) then
      raise exception 'Impossible de désactiver ou rétrograder le dernier administrateur.';
    end if;
    insert into public.audit_log(actor_id, action, entity_type, entity_id, details)
    values (auth.uid(), 'modification_droits', 'profile', new.id,
      jsonb_build_object('ancien_role', old.role, 'nouveau_role', new.role, 'anciennes_permissions', old.permissions, 'nouvelles_permissions', new.permissions, 'actif', new.active));
  end if;
  new.updated_at := now();
  return new;
end;
$$;
create trigger profile_changes_audit before update on public.profiles for each row execute procedure public.audit_profile_changes();

create or replace function public.handle_low_stock_alert()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if new.current_stock > new.min_stock then
    new.alert_armed := true;
  elsif new.current_stock <= new.min_stock and old.current_stock > old.min_stock and old.alert_armed then
    insert into public.stock_alerts(product_id, status, stock_at_alert)
    values (new.id, 'pending', new.current_stock);
    new.alert_armed := false;
  elsif new.current_stock <= new.min_stock and new.min_stock < old.min_stock and old.alert_armed then
    insert into public.stock_alerts(product_id, status, stock_at_alert)
    values (new.id, 'pending', new.current_stock);
    new.alert_armed := false;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
create trigger products_low_stock_alert before update of current_stock, min_stock on public.products for each row execute procedure public.handle_low_stock_alert();

create or replace function public.handle_product_initial_stock()
returns trigger language plpgsql security definer set search_path = public
as $$
declare actor uuid;
begin
  actor := coalesce(new.created_by, auth.uid());
  if new.current_stock > 0 and actor is not null then
    insert into public.stock_movements(product_id, movement_type, quantity, stock_before, stock_after, reason, actor_id)
    values (new.id, 'entree', new.current_stock, 0, new.current_stock, 'Stock initial', actor);
  end if;
  if new.current_stock <= new.min_stock then
    insert into public.stock_alerts(product_id, status, stock_at_alert) values (new.id, 'pending', new.current_stock);
    update public.products set alert_armed = false where id = new.id;
  end if;
  return new;
end;
$$;
create trigger products_initial_stock after insert on public.products for each row execute procedure public.handle_product_initial_stock();

create or replace function public.record_stock_movement(
  p_product_id uuid,
  p_movement_type text,
  p_quantity integer,
  p_reason text default null
) returns jsonb language plpgsql security definer set search_path = public
as $$
declare
  product_row public.products%rowtype;
  before_qty integer;
  after_qty integer;
begin
  if auth.uid() is null then raise exception 'Connexion requise.' using errcode = '28000'; end if;
  if not exists(select 1 from public.profiles where id = auth.uid() and active) then raise exception 'Compte inactif ou profil absent.'; end if;
  if p_quantity is null or p_quantity <= 0 then raise exception 'La quantité doit être un entier supérieur à zéro.'; end if;
  if p_movement_type not in ('sortie','entree','correction') then raise exception 'Type de mouvement invalide.'; end if;
  if p_movement_type in ('entree','correction') and not public.has_permission('manage_stock') then raise exception 'Droits insuffisants pour cette opération.' using errcode = '42501'; end if;
  if p_movement_type = 'correction' and length(trim(coalesce(p_reason,''))) = 0 then raise exception 'Un motif est obligatoire pour une correction.'; end if;

  select * into product_row from public.products where id = p_product_id and active = true for update;
  if not found then raise exception 'Produit introuvable ou archivé.'; end if;
  before_qty := product_row.current_stock;
  if p_movement_type = 'sortie' then
    after_qty := before_qty - p_quantity;
    if after_qty < 0 then raise exception 'Stock insuffisant. Stock actuel : %.', before_qty; end if;
  elsif p_movement_type = 'entree' then
    after_qty := before_qty + p_quantity;
  else
    -- Une correction est une quantité d'ajustement signée dans p_quantity n'est pas acceptée négative ; utiliser le motif pour journaliser uniquement une entrée de correction dans cette version.
    after_qty := before_qty + p_quantity;
  end if;

  update public.products set current_stock = after_qty where id = p_product_id;
  insert into public.stock_movements(product_id, movement_type, quantity, stock_before, stock_after, reason, actor_id)
  values (p_product_id, p_movement_type, p_quantity, before_qty, after_qty, nullif(trim(p_reason),''), auth.uid());
  insert into public.audit_log(actor_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'mouvement_stock', 'product', p_product_id, jsonb_build_object('type', p_movement_type, 'quantite', p_quantity, 'avant', before_qty, 'apres', after_qty));
  return jsonb_build_object('message', 'Mouvement enregistré.', 'stock_before', before_qty, 'stock_after', after_qty);
end;
$$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.stock_movements enable row level security;
alter table public.alert_recipients enable row level security;
alter table public.stock_alerts enable row level security;
alter table public.audit_log enable row level security;

create policy "profiles_read_self_or_admin" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin() or public.has_permission('manage_users'));
create policy "profiles_admin_update" on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
-- Le client ne peut jamais créer son propre profil ni promouvoir un compte via insert.

create policy "products_read_active" on public.products for select to authenticated using (active = true or public.is_admin() or public.has_permission('manage_products'));
create policy "products_insert_managers" on public.products for insert to authenticated with check ((public.is_admin() or public.has_permission('manage_products')) and (created_by is null or created_by = auth.uid()));
create policy "products_update_managers" on public.products for update to authenticated using (public.is_admin() or public.has_permission('manage_products')) with check (public.is_admin() or public.has_permission('manage_products'));

create policy "movements_read_authenticated" on public.stock_movements for select to authenticated using (exists(select 1 from public.profiles p where p.id = auth.uid() and p.active));
-- Les écritures de mouvements passent uniquement par la fonction RPC sécurisée.

create policy "recipients_admin_read" on public.alert_recipients for select to authenticated using (public.is_admin() or public.has_permission('manage_alerts'));
create policy "recipients_admin_insert" on public.alert_recipients for insert to authenticated with check ((public.is_admin() or public.has_permission('manage_alerts')) and (created_by is null or created_by = auth.uid()));
create policy "recipients_admin_delete" on public.alert_recipients for delete to authenticated using (public.is_admin() or public.has_permission('manage_alerts'));

create policy "alerts_admin_read" on public.stock_alerts for select to authenticated using (public.is_admin() or public.has_permission('manage_alerts'));
create policy "audit_admin_read" on public.audit_log for select to authenticated using (public.is_admin() or public.has_permission('manage_users'));

revoke all on function public.record_stock_movement(uuid,text,integer,text) from public, anon;
grant execute on function public.record_stock_movement(uuid,text,integer,text) to authenticated;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;
revoke all on function public.has_permission(text) from public, anon;
grant execute on function public.has_permission(text) to authenticated;

-- Important : crée le premier compte via Supabase Auth, puis promeus ce compte en admin depuis SQL Editor.
-- Voir README.md. Ne donne jamais accès au SQL Editor à un utilisateur standard.
