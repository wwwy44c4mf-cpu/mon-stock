import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return reply({ error: 'Méthode non autorisée.' }, 405);
  const url = Deno.env.get('SUPABASE_URL');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
  if (!url || !serviceKey) return reply({ error: 'Configuration Supabase manquante.' }, 500);
  const authHeader = req.headers.get('Authorization') || '';
  const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
  const { data: authData, error: authError } = await userClient.auth.getUser();
  if (authError || !authData.user) return reply({ error: 'Authentification requise.' }, 401);
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const { data: profile } = await admin.from('profiles').select('role, active').eq('id', authData.user.id).maybeSingle();
  if (!profile?.active || profile.role !== 'admin') return reply({ error: 'Seul l’administrateur principal peut inviter des utilisateurs.' }, 403);
  let body: { action?: string; email?: string; display_name?: string };
  try { body = await req.json(); } catch { return reply({ error: 'Corps de requête invalide.' }, 400); }
  if (body.action !== 'invite') return reply({ error: 'Action non reconnue.' }, 400);
  const email = String(body.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply({ error: 'Adresse e-mail invalide.' }, 400);
  const { data, error } = await admin.auth.admin.inviteUserByEmail(email, { data: { display_name: String(body.display_name || '').trim() } });
  if (error) return reply({ error: error.message }, 400);
  return reply({ message: `Invitation envoyée à ${email}.`, user_id: data.user?.id });
});
