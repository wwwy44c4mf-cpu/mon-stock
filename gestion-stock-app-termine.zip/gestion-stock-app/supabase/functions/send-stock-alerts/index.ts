import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const resendKey = Deno.env.get('RESEND_API_KEY');
  const fromEmail = Deno.env.get('ALERT_FROM_EMAIL');
  const appUrl = Deno.env.get('APP_BASE_URL') || '';
  if (!supabaseUrl || !serviceKey || !resendKey || !fromEmail) return json({ error: 'Configuration manquante : SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, RESEND_API_KEY ou ALERT_FROM_EMAIL.' }, 500);

  const adminClient = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });
  const authHeader = req.headers.get('Authorization') || '';
  const token = authHeader.replace(/^Bearer\s+/i, '');
  const cronSecret = Deno.env.get('CRON_SECRET');
  const isCronCall = Boolean(cronSecret) && req.headers.get('x-cron-secret') === cronSecret;
  let isServiceCall = token === serviceKey || isCronCall;
  if (!isServiceCall) {
    const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY') || '', { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) return json({ error: 'Authentification requise.' }, 401);
    const { data: profile } = await adminClient.from('profiles').select('role, active, permissions').eq('id', userData.user.id).maybeSingle();
    const allowed = profile?.active && (profile.role === 'admin' || profile.permissions?.manage_alerts === true);
    if (!allowed) return json({ error: 'Droits insuffisants.' }, 403);
  }

  let body: { test?: boolean } = {};
  try { body = await req.json(); } catch { /* corps vide accepté pour l'envoi programmé */ }
  const { data: recipients, error: recipientsError } = await adminClient.from('alert_recipients').select('email').eq('active', true);
  if (recipientsError) return json({ error: `Lecture des destinataires impossible : ${recipientsError.message}` }, 500);
  if (!recipients?.length) return json({ message: 'Aucun destinataire actif. Ajoute une adresse dans les réglages.' });

  const send = async (to: string[], subject: string, html: string) => {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: fromEmail, to, subject, html }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.message || `Le service e-mail a répondu ${response.status}`);
    return payload;
  };

  if (body.test) {
    try {
      await send(recipients.map((r) => r.email), 'Test des alertes — Mon Stock', `<p>Ceci est un e-mail de test de la configuration des alertes de Mon Stock.</p><p>Si tu reçois ce message, la configuration fonctionne.</p>`);
      return json({ message: `E-mail de test envoyé à ${recipients.length} destinataire(s).` });
    } catch (error) { return json({ error: `Échec de l'envoi du test : ${String(error)}` }, 502); }
  }

  const { data: pending, error: pendingError } = await adminClient.from('stock_alerts')
    .select('id, product_id, stock_at_alert, attempts, products(name, sku, barcode, min_stock, reorder_quantity)')
    .in('status', ['pending', 'failed']).lt('attempts', 5).order('created_at').limit(25);
  if (pendingError) return json({ error: `Lecture des alertes impossible : ${pendingError.message}` }, 500);
  let sent = 0; let failed = 0;
  for (const alert of pending || []) {
    const product = Array.isArray(alert.products) ? alert.products[0] : alert.products;
    if (!product) {
      await adminClient.from('stock_alerts').update({ status: 'failed', attempts: alert.attempts + 1, last_error: 'Produit introuvable.' }).eq('id', alert.id);
      failed++; continue;
    }
    const subject = `Réapprovisionnement nécessaire — ${product.sku}`;
    const html = `<h2>Stock à réapprovisionner</h2><p>Le stock du produit suivant a atteint son seuil minimum.</p><table><tr><td><b>Désignation</b></td><td>${escapeHtml(product.name)}</td></tr><tr><td><b>Référence</b></td><td>${escapeHtml(product.sku)}</td></tr><tr><td><b>Code-barres</b></td><td>${escapeHtml(product.barcode || '—')}</td></tr><tr><td><b>Stock constaté</b></td><td>${alert.stock_at_alert}</td></tr><tr><td><b>Seuil minimum</b></td><td>${product.min_stock}</td></tr><tr><td><b>Quantité suggérée</b></td><td>${product.reorder_quantity}</td></tr></table>${appUrl ? `<p><a href="${escapeHtml(appUrl)}">Ouvrir Mon Stock</a></p>` : ''}`;
    try {
      await send(recipients.map((r) => r.email), subject, html);
      await adminClient.from('stock_alerts').update({ status: 'sent', attempts: alert.attempts + 1, last_error: null, sent_at: new Date().toISOString() }).eq('id', alert.id);
      sent++;
    } catch (error) {
      await adminClient.from('stock_alerts').update({ status: 'failed', attempts: alert.attempts + 1, last_error: String(error).slice(0, 1000) }).eq('id', alert.id);
      failed++;
    }
  }
  return json({ message: `Traitement terminé : ${sent} alerte(s) envoyée(s), ${failed} échec(s).`, sent, failed, processed: (pending || []).length });
});

function escapeHtml(value: unknown) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] || char));
}
