-- Envoi automatique des alertes toutes les 5 minutes (à exécuter UNE fois dans le SQL Editor).
-- Prérequis : fonction send-stock-alerts déployée + secret CRON_SECRET défini :
--   supabase secrets set CRON_SECRET="une-longue-chaine-aleatoire"
-- Remplace les 3 valeurs ci-dessous. La clé « anon » sert uniquement à passer la vérification JWT de la passerelle.
create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.schedule(
  'mon-stock-alertes',
  '*/5 * * * *',
  $$
  select net.http_post(
    url     := 'https://VOTRE-PROJET.supabase.co/functions/v1/send-stock-alerts',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer VOTRE_CLE_ANON',
      'x-cron-secret', 'LA_MEME_CHAINE_QUE_CRON_SECRET'
    ),
    body    := '{}'::jsonb
  );
  $$
);
-- Pour arrêter : select cron.unschedule('mon-stock-alertes');
